package starwars.actions;

import starwars.SWActor;
import starwars.entities.Droid;

public class Ownership {

    private SWActor owner;

    private Droid droid;

    public Ownership(Droid d, SWActor a){

        this.droid = d;
        this.owner = a;
    }

    public SWActor getOwner(Droid d) {
        return this.owner;
    }

    public Droid getDroid(SWActor a){
        return this.droid;
    }

    public void setOwner(SWActor owner) {
        this.owner = owner;
    }

    public void setDroid(Droid droid) {
        this.droid = droid;
    }
}

