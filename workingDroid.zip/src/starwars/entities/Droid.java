package starwars.entities;

import edu.monash.fit2099.gridworld.Grid;
import edu.monash.fit2099.simulator.matter.Affordance;
import edu.monash.fit2099.simulator.space.Direction;
import edu.monash.fit2099.simulator.userInterface.MessageRenderer;
import starwars.*;
import starwars.actions.Attack;
import starwars.actions.Move;
import starwars.actions.Ownership;
import starwars.actions.Take;
import java.util.ArrayList;
import java.util.List;

public class Droid extends SWActor{

    /**
     * Constructor for this <code>SWEntity</code>. Will initialize this <code>SWEntity</code>'s
     * <code>messageRenderer</code> and set of capabilities.
     *
     * @param m the <code>messageRenderer</code> to display messages
     */
    private Ownership ownership;

    public Droid(Team team, int hitpoints, MessageRenderer m, SWWorld world) {
        super(team, hitpoints, m, world);

        this.addAffordance(new Take(this, m));
        ownership = new Ownership(this, null); // Initially no owner of the droid
        this.setForce(0);

    }


    @Override
    public void takeDamage(int damage) {
        super.takeDamage(damage);

        if (this.getHitpoints()<=0) {
            this.shortDescription = "a droid is immobile";
            this.longDescription  = "A Droid has run out of health. It needs to get fixed";

        } ;
    }

    public Ownership getOwnership(){
        return this.ownership;
    }

    /**
     * A symbol that is used to represent the LightSaber on a text based user interface
     *
     * @return 	A String containing a single character.
     * @see 	{@link starwars.SWEntityInterface#getSymbol()}
     */
    @Override
    public void act() {
        if (this.getHitpoints() > 0) { // enough health
            if (this.ownership.getOwner(this) != null) {
                //get the location of the Droid and describe it
                SWLocation location = SWWorld.getEntitymanager().whereIs(this);
                say(this.getShortDescription() + " [" + this.getHitpoints() + "] is at " + location.getShortDescription());

                //get the contents of the location
                List<SWEntityInterface> contents = SWWorld.getEntitymanager().contents(location);

                //and find the owner
                boolean ownerFound = false;
                if (contents.size() > 1) { // if it is equal to one, the only thing here is this Droid, so there is nothing to report
                    for (SWEntityInterface entity : contents) {
                        if (entity != this) { // don't include self in scene description
                            if (entity.getSymbol() == this.ownership.getOwner(this).getSymbol()) {
                                say("A Droid is in the same location as its owner");
                                ownerFound = true;
                                if (location.getSymbol() == 'b'){ // check if in the Badlands
                                    this.takeDamage(100); //lose health if in Badlands
                                }
                            }
                        }
                    }
                }

                Direction heading = null;

                // Owner is not in the same location
                if(!ownerFound){
                    SWLocation n = (SWLocation) location.getNeighbour(Grid.CompassBearing.NORTH);
                    SWLocation nw = (SWLocation) location.getNeighbour(Grid.CompassBearing.NORTHWEST);
                    SWLocation ne = (SWLocation) location.getNeighbour(Grid.CompassBearing.NORTHEAST);
                    SWLocation w = (SWLocation) location.getNeighbour(Grid.CompassBearing.WEST);
                    SWLocation s = (SWLocation) location.getNeighbour(Grid.CompassBearing.SOUTH);
                    SWLocation sw = (SWLocation) location.getNeighbour(Grid.CompassBearing.SOUTHWEST);
                    SWLocation se = (SWLocation) location.getNeighbour(Grid.CompassBearing.SOUTHEAST);
                    SWLocation e = (SWLocation)location.getNeighbour(Grid.CompassBearing.EAST);

                    if (n != null && n == SWWorld.getEntitymanager().whereIs(this.ownership.getOwner(this))){
                        //SWWorld.getEntitymanager().setLocation(this, n);

                        heading = Grid.CompassBearing.NORTH;
                        say(getShortDescription() + " is heading " + heading + " next.");
                        Move myMove = new Move(heading, messageRenderer, world);

                        scheduler.schedule(myMove, this, 1);

                    }else if (nw != null && nw == SWWorld.getEntitymanager().whereIs(this.ownership.getOwner(this))){
                        //SWWorld.getEntitymanager().setLocation(this, nw);
                        heading = Grid.CompassBearing.NORTHWEST;
                        say(getShortDescription() + " is heading " + heading + " next.");
                        Move myMove = new Move(heading, messageRenderer, world);

                        scheduler.schedule(myMove, this, 1);

                    }else if (ne != null && ne == SWWorld.getEntitymanager().whereIs(this.ownership.getOwner(this))){
                        //SWWorld.getEntitymanager().setLocation(this, ne);
                        //say(getShortDescription() + "is heading " + ne + " next.");
                        heading = Grid.CompassBearing.NORTHEAST;
                        say(getShortDescription() + " is heading " + heading + " next.");
                        Move myMove = new Move(heading, messageRenderer, world);

                        scheduler.schedule(myMove, this, 1);

                    }else if (w != null && w == SWWorld.getEntitymanager().whereIs(this.ownership.getOwner(this))){
                        //SWWorld.getEntitymanager().setLocation(this, w);
                        //say(getShortDescription() + "is heading " + w + " next.");
                        heading = Grid.CompassBearing.WEST;
                        say(getShortDescription() + " is heading " + heading + " next.");
                        Move myMove = new Move(heading, messageRenderer, world);

                        scheduler.schedule(myMove, this, 1);

                    }else if (s != null && s == SWWorld.getEntitymanager().whereIs(this.ownership.getOwner(this))){
                        //SWWorld.getEntitymanager().setLocation(this, s);
                        //say(getShortDescription() + "is heading " + s + " next.");
                        heading = Grid.CompassBearing.SOUTH;
                        say(getShortDescription() + " is heading " + heading + " next.");
                        Move myMove = new Move(heading, messageRenderer, world);

                        scheduler.schedule(myMove, this, 1);

                    }else if (sw != null && sw == SWWorld.getEntitymanager().whereIs(this.ownership.getOwner(this))){
                        //SWWorld.getEntitymanager().setLocation(this, sw);
                        //say(getShortDescription() + "is heading " + sw + " next.");
                        heading = Grid.CompassBearing.SOUTHWEST;
                        say(getShortDescription() + " is heading " + heading + " next.");
                        Move myMove = new Move(heading, messageRenderer, world);

                        scheduler.schedule(myMove, this, 1);

                    }else if(se != null && se == SWWorld.getEntitymanager().whereIs(this.ownership.getOwner(this))){
                        //SWWorld.getEntitymanager().setLocation(this, se);
                        //say(getShortDescription() + "is heading " + n + " next.");
                        heading = Grid.CompassBearing.SOUTHEAST;
                        say(getShortDescription() + " is heading " + heading + " next.");
                        Move myMove = new Move(heading, messageRenderer, world);

                        scheduler.schedule(myMove, this, 1);

                    }else if (e != null && e == SWWorld.getEntitymanager().whereIs(this.ownership.getOwner(this))){
                        //SWWorld.getEntitymanager().setLocation(this, e);
                        //say(getShortDescription() + "is heading " + e + " next.");
                        heading = Grid.CompassBearing.EAST;
                        say(getShortDescription() + " is heading " + heading + " next.");
                        Move myMove = new Move(heading, messageRenderer, world);

                        scheduler.schedule(myMove, this, 1);

                    }else{// cannot find the owner; pick a direction at random
                        if (Math.random() > 0.55){
                            ArrayList<Direction> possibledirections = new ArrayList<Direction>();

                            // build a list of available directions
                            for (Grid.CompassBearing d : Grid.CompassBearing.values()) {
                                if (SWWorld.getEntitymanager().seesExit(this, d)) {
                                    possibledirections.add(d);
                                }
                            }

                            heading = possibledirections.get((int) (Math.floor(Math.random() * possibledirections.size())));
                            //SWLocation headingloc = (SWLocation) location.getNeighbour(heading);
                            //SWWorld.getEntitymanager().setLocation(this, headingloc);
                            say(getShortDescription() + "i s heading " + heading + " next.");
                            Move myMove = new Move(heading, messageRenderer, world);

                            scheduler.schedule(myMove, this, 1);
                        }
                    }
                }
                // ========================

                // Check if new loction is in Badlands
                SWLocation newlocation = (SWLocation) location.getNeighbour(heading);
                if ((newlocation != null && newlocation.getSymbol() == 'b' )) {
                    this.takeDamage(100); //lose health if in Badlands
                }

            }   // no owner
                //dont move

        }else { // run out of health; becomes immobile
            say("A Droid is immobile, because it has run out of health ");
        }
    }
}
