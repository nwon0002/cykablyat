/**
 * A package for modeling common behaviours for Star Wars actors
 */
/**
 * @author rober_000
 *
 */
package starwars.entities.actors.behaviors;