package starwars.entities.actors;

import java.util.ArrayList;
import java.util.List;

import edu.monash.fit2099.gridworld.Grid;
import edu.monash.fit2099.simulator.space.Direction;
import edu.monash.fit2099.simulator.userInterface.MessageRenderer;
import starwars.*;
import starwars.actions.Move;
import starwars.entities.actors.behaviors.Patrol;

public class SandCrawler extends SWActor {

    private Patrol path;

    private SWGrid interiorGrid;

    private SWGrid worldGrid;
    /**
     * Constructor for the <code>SandCrawler</code> class. This constructor will,
     * <ul>
     * 	<li>Initialize the message renderer for the <code>SandCrawler</code></li>
     * 	<li>Initialize the world for this <code>SandCrawler</code></li>
     * </ul>
     *
     * @param m <code>MessageRenderer</code> to display messages.
     * @param world the <code>SWWorld</code> world to which this <code>SandCrawler</code> belongs to
     *
     */
    public SandCrawler(MessageRenderer m, SWWorld world, Direction [] moves) {
        super(Team.NEUTRAL, 50, m, world);

        this.setShortDescription("Jawa Sandcrawler");
        this.setLongDescription("Sandcrawler - vehicle that scavanges the planet Tatooine for droids");

        path = new Patrol(moves);

        // Interior
        SWLocation loc;

        worldGrid = world.getGrid();
        int height = world.height();
        int width = world.width();


    }


    @Override
    public void act() {
        Direction newdirection = path.getNext();
        if (newdirection != null){ // Move every second turn

            //get the location of the SandCrawler and describe it
            SWLocation location = SWWorld.getEntitymanager().whereIs(this);
            say(this.getShortDescription() + " [" + this.getHitpoints() + "] is at " + location.getShortDescription());

            //get the contents of the location
            List<SWEntityInterface> contents = SWWorld.getEntitymanager().contents(location);

            if (contents.size() > 1) { // if it is equal to one, the only thing here is this SandCrawler, so there is nothing to report
                for (SWEntityInterface entity : contents) {
                    if (entity != this) { // don't include self in scene description
                        if (entity.getSymbol() == "D") { // If found Droid
                            say(this.getShortDescription() + " found A Droid");
                            Droid droid = (Droid) entity;
                            droid.setOwner(this);
                        }
                    }
                }
            }
            say(getShortDescription() + " is heading " + newdirection+" next.");
            Move myMove = new Move(newdirection, messageRenderer, world);

            scheduler.schedule(myMove, this, 1);
        }
    }

}